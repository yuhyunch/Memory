//
//  PlaceSaveViewController.swift
//  Memory
//
//  Created by Yuhyun Chung on 11/16/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import UIKit
import Alamofire

class PlaceSaveViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate, UITextFieldDelegate {
    
    let list = ["Happier","Without me","High Hopes","Broken","Natural","Lucid Dreams","I Like It"]
    
    // singleton for userdata.
    var model:UserData?
    
    var displayLongtitude = "";
    var displayLatitude = "";
    
    //var onFinish: (name: String, name: String)?
    
    @IBOutlet weak var longtitudeLabel: UILabel!
    @IBOutlet weak var latitudeLabel: UILabel!
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var subtitleTextField: UITextView!
    
    @IBOutlet weak var songTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        model = UserData.sharedInstance
        titleTextField.delegate = self
        subtitleTextField.delegate = self
        songTextField.delegate = self
        artistTextField.delegate = self
        
        self.longtitudeLabel.text = displayLongtitude
        self.latitudeLabel.text = displayLatitude

        // Do any additional setup after loading the view.
    }
    
    @IBAction func CancelAction(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func backgroundTapped(_ sender: UITapGestureRecognizer) {
        titleTextField.resignFirstResponder()
        subtitleTextField.resignFirstResponder()
        songTextField.resignFirstResponder()
        artistTextField.resignFirstResponder()
    }
    
    @IBAction func savePlace(_ sender: UIBarButtonItem) {
        
        print("savePlace")
        
        var check: Bool = false
        
        if(titleTextField.text == ""){
            print("title")
            check = true
        }
        else if(subtitleTextField.text == ""){
            print("subtitle")
            check = true
        }
        else if(songTextField.text == ""){
            check = true
        }
        else if(artistTextField.text == ""){
            check = true
        }
        else{
            // all the required fields are filled.
            
            let newTitle: String = titleTextField.text!
            let newSubtitle: String = subtitleTextField.text!
            let newLatitude: String = latitudeLabel.text!
            let newLongtitude: String = longtitudeLabel.text!
            let newSongTitle: String = songTextField.text!
            let newArtist: String = artistTextField.text!
            
            let newSong: Song = Song(title: newSongTitle, artist: newArtist )
            
            
            let newPlace: Place = Place(name: newTitle, subtitle: newSubtitle, latitude: newLatitude, longitude: newLongtitude)
            newPlace.addSong(song: newSong)
            model?.addPlace(name: newTitle, place: newPlace)
            
            print("working")
            //self.dismiss(animated: true, completion: nil)
        }
        
        if(check){
            let alert = UIAlertController(title: "Warning!", message: "Missing required information.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { (action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
        }
        
       
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default , reuseIdentifier: "songCell")
        
        cell.textLabel?.text = list[indexPath.row]
        
        return cell
    }
    

}
