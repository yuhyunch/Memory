//
//  PlaceInfoViewController.swift
//  Memory
//
//  Created by Yuhyun Chung on 12/4/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import UIKit

class PlaceInfoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate, UITextFieldDelegate  {
    
    var selectedCellIndex = 0
    
    // singleton for userdata.
    var model:UserData?
    
    var songs: Array<Song> = Array<Song>()
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleTextField: UITextView!
    @IBOutlet weak var longtitudeLabel: UILabel!
    @IBOutlet weak var LatitudeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        model = UserData.sharedInstance
        
        titleLabel.text = model?.getPlaceName(index: selectedCellIndex)
        subtitleTextField.text = model?.getSubtitle(index: selectedCellIndex)
        LatitudeLabel.text = model?.getLatitude(index: selectedCellIndex)
        longtitudeLabel.text = model?.getLongtitiude(index: selectedCellIndex)
        
        let temp: Array<Song> = Array<Song>()
        
        songs = model?.getSongs(index: selectedCellIndex) ?? temp
        
    }

    @IBAction func cancelButton(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func backgroundTap(_ sender: UITapGestureRecognizer) {
        subtitleTextField.resignFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func saveButton(_ sender: UIBarButtonItem) {
        
        var check: Bool = false
        
        if(subtitleTextField.text == ""){
            print("subtitle")
            check = true
        }
        else{
            // all the required fields are filled.
            
            let newSubtitle: String = subtitleTextField.text!
            
            model?.setSubtitle(index: selectedCellIndex, name: titleLabel.text!, subtitle: newSubtitle, latitude: LatitudeLabel.text!, longtitude: longtitudeLabel.text!)
            
            
            
            //print(model?.getPlaceName(index: 1))
            //self.dismiss(animated: true, completion: nil)
        }
        
        if(check){
            let alert = UIAlertController(title: "Warning!", message: "Missing required information.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { (action) in alert.dismiss(animated: true, completion: nil)}))
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(songs.count)
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default , reuseIdentifier: "songCell")
        
        cell.textLabel?.text = songs[indexPath.row].getTitle()
        
        return cell
    }
    
    
    


}
