//
//  Song.swift
//  Memory
//
//  Created by Yuhyun Chung on 12/3/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import Foundation


class Song: NSObject, NSCoding{
    
    private var title: String?
    private var artist: String?
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(title, forKey: "title")
        aCoder.encode(artist, forKey: "artist")
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let t_title = aDecoder.decodeObject(forKey: "title") as? String, let t_artist = aDecoder.decodeObject(forKey: "artist") as? String else { return nil}
        self.init(title: t_title, artist: t_artist)
    }
    
    init(title: String, artist: String){
        self.title = title
        self.artist = artist
    }
    
    func getTitle() -> String{
        return self.title!
    }
    
    func getArtist() -> String{
        return self.artist!
    }
    
}
