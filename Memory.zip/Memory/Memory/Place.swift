//
//  Place.swift
//  Memory
//
//  Created by Yuhyun Chung on 11/16/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import Foundation
import MapKit

class Place: NSObject, NSCoding{
    
    private var name: String?
    private var subtitle: String?
    private var latitude: String?
    private var longitude: String?
    private var songs: Array<Song> = Array();
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "name")
        aCoder.encode(subtitle, forKey: "subtitle")
        aCoder.encode(latitude, forKey: "latitude")
        aCoder.encode(longitude, forKey: "longtitude")
        aCoder.encode(songs, forKey: "songs")
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let t_name = aDecoder.decodeObject(forKey: "name") as? String, let t_subtitle = aDecoder.decodeObject(forKey: "subtitle") as? String, let t_latitude = aDecoder.decodeObject(forKey: "latitude") as? String, let t_longtitude = aDecoder.decodeObject(forKey: "longtitude") as? String else { return nil}
        self.init(name: t_name, subtitle: t_subtitle, latitude: t_latitude, longitude: t_longtitude)
    }
    
    
    init(name: String, subtitle: String, latitude: String, longitude: String){
        self.name = name
        self.subtitle = subtitle
        self.latitude = latitude
        self.longitude = longitude
    }
    
    func addSong(song: Song){
        songs.append(song)
    }
    
    func removeSong(song: Song){
       
        for i in 0..<songs.count{
            
            // if we find the target song.
            if(songs[i].getTitle() == song.getTitle()){
                songs.remove(at: i)
            }
            
        }
        
    }
    
    func getTitle() -> String{
        return self.name!
    }
    
    func getSubtitle()-> String{
        return self.subtitle!
    }
    
    func getLatitude() -> String {
        return self.latitude!
    }
    
    func getLongtitude() -> String {
        return self.longitude!
    }
    
    func getSongs() -> Array<Song> {
        return self.songs
    }
    
    
    
}
