//
//  Constant.swift
//  Memory
//
//  Created by Yuhyun Chung on 12/3/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import Foundation

class Constant{
    static var accessToken = "";
    
}
