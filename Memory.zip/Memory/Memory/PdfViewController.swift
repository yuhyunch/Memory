//
//  PdfViewController.swift
//  Memory
//
//  Created by Yuhyun Chung on 12/6/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import UIKit
import PDFKit
class PdfViewController: UIViewController {
    @IBOutlet weak var image2: UIImageView!
    
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var pdfView: PDFView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let path =  Bundle.main.path(forResource: "pdf", ofType: "pdf"){
            let url = URL(fileURLWithPath: path)
            if let pdfDocument = PDFDocument(url: url){
                pdfView.autoScales = true
                pdfView.displayMode = .singlePageContinuous
                pdfView.displayDirection = .vertical
                pdfView.document = pdfDocument
                
                captureImage(pdfDocument: pdfDocument)
            }
        }

        // Do any additional setup after loading the view.
    }
    
    func captureImage(pdfDocument:PDFDocument){
//        if let page1 = pdfDocument.page(at: 1){
//            image1.image = page1.thumbnail(of: CGSize(width: image1.frame.size.width, height: image1.frame.size.height), for: .artBox)
//        }
//        if let page2 = pdfDocument.page(at: 2){
//            image2.image = page2.thumbnail(of: CGSize(width: image2.frame.size.width, height: image2.frame.size.height), for: .artBox)
        //        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
