//
//  UserData.swift
//  Memory
//
//  Created by Yuhyun Chung on 11/16/18.
//  Copyright © 2018 Yuhyun Chung. All rights reserved.
//

import Foundation

class UserData: NSObject, NSCoding{
    
    
    //singleton.
    static let sharedInstance = UserData(firstname: "Yuhyun", Lastname: "Chung")
    
    //let userData: UserData
    
    //User's info
    private var firstName: String?
    private var lastName: String?
    
    // place Dictionary
    private var placesDictionary: [String:Place]
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(firstName, forKey: "firstName")
        aCoder.encode(lastName, forKey: "lastName")
        aCoder.encode(placesDictionary, forKey: "placesDictionary")
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let firstName = aDecoder.decodeObject(forKey: "firstName") as! String
        let lastName = aDecoder.decodeObject(forKey: "lastName") as! String
        let placesDictionary = aDecoder.decodeObject(forKey: "placesDictionary") as! [String:Place]
        self.init(firstName: firstName, lastName: lastName, placesDictionary: placesDictionary)
    }
    
    //Property list.
    private var filepath: String
    
    private let kPlacenameKey = "place"
    private let kSubtitleKey = "subtitle"
    private let kLongtitudeKey = "longtitude"
    private let kLatititudeKey = "latitude"
    private let kSongKey = "song"
    private let kArtistKey = "artist"
    

    private var Places: [[String: String]]{
        var array = [[String:String]]()

        // ??? how to add favorite also!

        for place in placesDictionary.values{
            let userDataDictionary = [
                kPlacenameKey: place.getTitle(),
                kSubtitleKey: place.getSubtitle(),
                kLongtitudeKey: place.getLongtitude(),
                kLatititudeKey: place.getLatitude(),
                kSongKey: place.getSongs()[0].getTitle(),
                kArtistKey: place.getSongs()[0].getArtist()
            ]
            array.append(userDataDictionary)
        }
        return array
    }
    
    init(firstName: String, lastName: String, placesDictionary: [String: Place]){
        self.filepath = ""
        self.firstName = firstName
        self.lastName = lastName
        self.placesDictionary = placesDictionary
    }
    
    
    
    init(firstname: String, Lastname: String) {
        
        self.firstName = firstname
        self.lastName = Lastname
    
        //Property list.
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = paths.first!
        self.filepath = "\(documentDirectory)/userData.plist"
        
        if let placeDictionary = NSArray(contentsOfFile: filepath) as? [[String: String]]{

            placesDictionary = [String:Place]()

            for place in placeDictionary{


                let temp:Place = Place(name: place[kPlacenameKey]!, subtitle: place[kSubtitleKey]!, latitude: place[kLatititudeKey]!, longitude: place[kLongtitudeKey]!)
                let t_song = Song(title: place[kSongKey]!, artist: place[kArtistKey]!)
                temp.addSong(song: t_song)

                placesDictionary[place[kPlacenameKey]!] = temp

            }
        }
        else{
        
            placesDictionary = [String:Place]()
            
            let firstPlace: Place = Place(name: "USC", subtitle: "University", latitude: "127.12", longitude: "12.33")
            let firstSong: Song = Song(title: "Let me go", artist: "Duban Smith")
            firstPlace.addSong(song: firstSong)
            let secondSong: Song = Song(title: "Happier", artist: "Marshmellow")
            firstPlace.addSong(song: secondSong)
            let thirdSong: Song = Song(title: "Oh Child", artist: "Marshmellow")
            firstPlace.addSong(song: thirdSong)
        
        let firthSong: Song = Song(title: "Brighter", artist: "Marshmellow")
            firstPlace.addSong(song: firthSong)
            placesDictionary["USC"] = firstPlace
        
            let temp1: Song = Song(title: "Brighter", artist: "Marshmellow")
            let secondPlace: Place = Place(name: "Korea", subtitle: "the country where I came from", latitude: "65.298", longitude: "129.39")
            secondPlace.addSong(song: temp1)
            placesDictionary["Korea"] = secondPlace
        
//            firstPlace.addSong(song: temp1)
            
        }

        
    }
    
    func addPlace(name: String, place: Place){
        placesDictionary[name] = place
        print("dd")
        save()
    }
    
    func getSize() -> Int{
        return placesDictionary.count
    }
    
    func getPlaceName(index: Int) -> String{
        
        if(placesDictionary.count == 0){
            return "0 place saved."
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            
            return keys[index]
        }
        
    }

    func getSubtitle(index: Int) -> String{
        
        if(placesDictionary.count == 0){
            return "0 place saved."
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            
            let t_place:Place = placesDictionary[keys[index]]!
            let t_subtitle: String = t_place.getSubtitle()
            
            return t_subtitle
        }
        
    }
    
    func setSubtitle(index: Int, name: String, subtitle: String, latitude: String, longtitude: String){
        if(placesDictionary.count == 0){
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            let t_key = keys[index]
            let newPlace: Place = Place(name: name, subtitle: subtitle, latitude: latitude, longitude: longtitude)
            placesDictionary.updateValue(newPlace, forKey: t_key)
            
        }
    }
    
    func getLatitude(index: Int) -> String{
        
        if(placesDictionary.count == 0){
            return "0 place saved."
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            
            let t_place:Place = placesDictionary[keys[index]]!
            let t_latitude: String = t_place.getLatitude()
            
            return t_latitude
        }
        
    }
    
    func getLongtitiude(index: Int) -> String{
        
        if(placesDictionary.count == 0){
            return "0 place saved."
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            
            let t_place:Place = placesDictionary[keys[index]]!
            let t_longtitude: String = t_place.getLongtitude()
            
            return t_longtitude
        }
        
    }
    
    func getSongs(index: Int) -> Array<Song>{
        
        let temp: Array<Song> = Array();
        
        if(placesDictionary.count == 0){
            return temp
        }
        else{
            
            let keys = Array(placesDictionary.keys)
            
            let t_place:Place = placesDictionary[keys[index]]!
            return t_place.getSongs()
        }
        
    }
    
//    func save() {
//        
//        do {
//            let fileManager = FileManager.default
//            let documentDirectory = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
//            let saveFile = documentDirectory.appendingPathComponent("userdata.bin")
//            let userdata = NSKeyedArchiver.archivedData(withRootObject: userData )
//            try userdata.write(to: saveFile)
//        }
//        catch{
//            
//        }
//        
//    }
    
    func save(){
        (Places as NSArray).write(toFile: filepath, atomically: true)
    }
    
}
